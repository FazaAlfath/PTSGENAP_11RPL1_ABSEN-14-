<?php 

    $conn = mysqli_connect('localhost', 'root', '', 'inventarislabrpl');

    $nama = $_POST['nama'];
    $kode = $_POST['kode'];
    $jenis = $_POST['jenis'];

    $data = [];

    $insert = mysqli_query($conn, "INSERT INTO barang VALUES( '' , '$nama', '$kode', '$jenis' )");

    if( $insert == true ){
        $data['hasil']['respon'] = true; 
    }else{
        $data['hasil']['respon']  =false;
    }

    echo json_encode($data);

?>