<?php 

    $conn = mysqli_connect('localhost', 'root', '', 'inventarislabrpl');
   
    $id = $_POST['id'];
    $nama = $_POST['nama'];
    $kode = $_POST['kode'];
    $jenis = $_POST['jenis'];

    $update = mysqli_query($conn, "UPDATE barang SET b_nama = '$nama', b_kode = '$kode', b_jenis = '$jenis' WHERE b_id = $id ");

    if( $update ==  true ){
        $data['hasil']['respon'] = true; 
    }else{
        $data['hasil']['respon']  =false;
    }

    echo json_encode($data);

?>