<?php 

    $conn = mysqli_connect('localhost', 'root', '', 'inventarislabrpl');
   
    $username = $_POST['username'];
    $password = $_POST['password'];

    $login = mysqli_query($conn, "SELECT u_username AND u_password FROM user");

    if( $login ==  true ){
        $data['hasil']['respon'] = true; 
    }else{
        $data['hasil']['respon']  =false;
    }

    echo json_encode($data);

?>