<?php 

    $conn = mysqli_connect('localhost', 'root', '', 'inventarislabrpl');
   
    $id = $_POST['id'];

    $update = mysqli_query($conn, "DELETE FROM barang WHERE b_id = $id ");

    if( $update ==  true ){
        $data['hasil']['respon'] = true; 
    }else{
        $data['hasil']['respon']  =false;
    }

    echo json_encode($data);

?>